module.exports = [
    "Multi Chain Flare NFT", "FNCT", "7878",
]
