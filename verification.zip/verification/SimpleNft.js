module.exports = [
    "XKCD Token",
    "FXKCD",
    "1000000000000000000",
]
